library(testthat)
library(sdstudio)

# test_check("sdstudio")
